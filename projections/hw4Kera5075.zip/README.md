# Homework 4 by Kevin Rau

- 4 Hours to Complete 

## Using the Makefile

- Make Object file `make`

- Runz Executable `./hw4`

- Clean Object File `make clean`

## Program Key Bindings/Interaction

- Key bindings:

- Key bindings
  m          Toggle between perspective and orthogonal and first person
  +/-        Changes field of view 
  arrows     Change view angle | move around in first person 
  PgDn/PgUp  Zoom in and out
  0          Reset view angle
  w          Increase Dim (Y-axis)
  s          Decrease Dim (Y-axis)
  ESC        Exit
